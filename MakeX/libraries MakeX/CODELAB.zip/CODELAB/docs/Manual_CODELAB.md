# CODELAB Arduino Library (RP2040)

Beginner‑friendly API for the CODELAB board. One line include, easy functions, and a ready‑to‑use OLED `display` object.

```cpp
#include <CODELAB.h>

void setup() {
  CODELAB::begin();                 // <— call once
  display.clearDisplay();
  display.setCursor(0,0);
  display.println("Hey! CODELAB");
  display.println(sen(0));          // prints ADC0 reading
  display.display();

  motor(0, 50);                     // 50% forward on motor0 (pins 25/24)
  servo(0, 90);                     // servo on pin 17 to 90 deg
  beep();                           // short beep
}

void loop() {
  if (sw(0)) motor(1, 60);          // button B0 pressed
  else       motor(1, 0);
}
```

## Pinout mapping (default)

- **Motors (H-bridge 2 pins each)**  
  - motor(0): **25,24**  
  - motor(1): **23,22**  
  - motor(2): **21,20**  
  - motor(3): **19,18**  

- **Buttons** (INPUT_PULLUP):  
  - sw(0): **2**  
  - sw(1): **3**  

- **Servos**:  
  - servo(0..5): **17,16,15,14,13,12**

- **OLED I2C**: **SDA=4, SCL=5**, addr **0x3C**, size **128x64**  
  Global object: `Adafruit_SSD1306 display` (already ready after `CODELAB::begin()`)

- **ADC128S102** (SPI): **CS=9** (default). The library will call `_adc.begin()` using your uploaded `ADC128S102` lib.

- **Buzzer**: **pin 11**  
  Helpers: `buzz(freq, ms)`, `beep(ms=120)`, `beepOK()`, `beepErr()`

> If your board revision uses different pins, edit the arrays/defines at the top of `CODELAB.h`.

## API reference

### `CODELAB::begin()`
Initialize everything (pins, OLED on I2C pins 4/5, ADC, buzzer). Call once in `setup()`.

### `motor(index, speedPercent)`
Also see `stop(index)` to stop that motor quickly.
`index` = 0..3. `speedPercent` = -100..100.  
Positive: IN1 PWM, Negative: IN2 PWM, 0: brake/coast (both 0).

### `stop(index)`
Stops motor `index` (coast). Equivalent to `motor(index, 0)`.

### `sw(index)`
`index` = 0..1. Returns **1 when pressed**, 0 otherwise. Internally uses `INPUT_PULLUP` and inverts the logic.

### `servo(index, angleDeg)`
`index` = 0..5, `angleDeg` = 0..180. Attaches on first use.

### `sen(channel)`
`channel` = 0..7. Returns 12‑bit ADC value (0..4095) from ADC128S102 via your provided driver.

### `display` (OLED)
Global `Adafruit_SSD1306` named **display**. After `CODELAB::begin()` you can call any Adafruit SSD1306 functions:
```
display.clearDisplay();
display.setTextSize(1);
display.setTextColor(WHITE);
display.setCursor(0,0);
display.println("Hey! CODELAB");
display.println(sen(0));
display.display();
```

### Buzzer
- `buzz(freqHz, durationMs)`  
- `beep(durationMs=120)`  
- `beepOK()`, `beepErr()`

## Notes on ADC128S102 (RP2040 / Arduino MBed core)

This library calls `_adc.begin()` and expects your uploaded `ADC128S102` library to handle SPI initialization. If your driver requires explicit pins or CS:
- Define `#define CODELAB_ADC_CS <yourCS>` **before** including `<CODELAB.h>`, or
- Modify `CODELAB.cpp` to call a specific `begin(SPI, CS, SPISettings)` if your variant needs it.

If you previously used `MbedSPI mySPI = MbedSPI(0,7,6);`, keep your ADC driver configured for those pins. This wrapper will not fight custom settings inside your ADC lib.

## Troubleshooting
- If `display` shows nothing: check wiring (SDA=4, SCL=5) and 0x3C address. Some modules are 0x3D.
- Motors not moving: verify H-bridge enable pins and that pins (25..18) are PWM-capable; try smaller loads.
- Buttons inverted: `sw()` returns 1 when pressed by design.
- ADC reads 0: ensure ADC128S102 CS on pin 9 (or change define), SPI pins & GND/Vref wiring.
- Servo jitter: provide separate power for servos; ground must be common.

## License
MIT (educational use friendly)
