#pragma once
#include <Arduino.h>
#include <Servo.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ADC128S102.h>

// ========== Pin Map (adjust here if your board revision differs) ==========
// Motors (each motor uses 2 pins: IN1, IN2).
// motor(0) -> pins 25,24
// motor(1) -> pins 23,22
// motor(2) -> pins 21,20
// motor(3) -> pins 19,18
static const uint8_t CODELAB_MOTOR_PINS[4][2] = {
  {25, 24}, {23, 22}, {21, 20}, {19, 18}
};

// Buttons with pullups
// sw(0) -> pin 2  (B0)
// sw(1) -> pin 3  (B1)
static const uint8_t CODELAB_BTN_PINS[2] = {2, 3};

// Servos
// servo(0..5) -> pins 17,16,15,14,13,12
static const uint8_t CODELAB_SERVO_PINS[6] = {17, 16, 15, 14, 13, 12};

// OLED I2C on SDA=4, SCL=5 (address 0x3C), 128x64
#define CODELAB_OLED_ADDR 0x3C
#define CODELAB_OLED_W    128
#define CODELAB_OLED_H    64
static TwoWire CODELAB_Wire(4, 5);

// ADC128S102 on SPI with CS = 9
#ifndef CODELAB_ADC_CS
#define CODELAB_ADC_CS 9
#endif

// Buzzer pin
#ifndef CODELAB_BUZZER_PIN
#define CODELAB_BUZZER_PIN 11
#endif

// Forward declare global display so sketches can use 'display.xxx' directly
extern Adafruit_SSD1306 display;

namespace CODELAB {

  // Call this once in setup(). Initializes pins, I2C OLED, ADC, etc.
  void begin();

  // Motor: speed in -100..100 (%). Positive = forward (IN1 PWM), Negative = reverse (IN2 PWM).
  // Example: motor(0, 50);  // 50% forward
  void motor(int index, int speedPercent);
  void motor_stop(int index);

  // Stop motor index immediately (coast):
  void stop(int index);

  // Button: returns 1 when pressed, 0 when released (uses INPUT_PULLUP).
  int sw(int index);

  // Servo: angle 0..180; attaches lazily on first use.
  void servo(int index, int angleDeg);

  // ADC read: 0..4095 (12-bit). Channel 0..7
  int sen(uint8_t channel);

  // Buzzer helpers
  void buzz(int freqHz, int durationMs);
  void beep(int durationMs = 120);
  void beepOK();
  void beepErr();
}

// Expose friendly global functions without namespace for beginners
inline void motor(int i, int s) { CODELAB::motor(i, s); }
inline void motor_stop(int i) { CODELAB::motor_stop(i); }
inline int  sw(int i)           { return CODELAB::sw(i); }
inline void servo(int i, int a) { CODELAB::servo(i, a); }
inline int  sen(uint8_t ch)     { return CODELAB::sen(ch); }
inline void buzz(int f, int ms) { CODELAB::buzz(f, ms); }
inline void beep(int ms=120)    { CODELAB::beep(ms); }
inline void stop(int i)        { CODELAB::stop(i); }

