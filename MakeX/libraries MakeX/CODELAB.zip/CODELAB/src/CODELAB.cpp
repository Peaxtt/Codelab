#include "CODELAB.h"

// Global display object (available to sketches)
Adafruit_SSD1306 display(CODELAB_OLED_W, CODELAB_OLED_H, &CODELAB_Wire, -1);

// Internals
static Servo _servos[6];
static bool  _servoAttached[6] = {false,false,false,false,false,false};
static bool  _inited = false;

static ADC128S102 _adc;  // Using provided ADC128S102 library

// Helper: clamp and map percentage to 0..255
static uint8_t pctToPWM(int pct) {
  if (pct < 0) pct = -pct;
  if (pct > 100) pct = 100;
  return map(pct, 0, 100, 0, 255);
}

namespace CODELAB {

void begin() {
  if (_inited) return;
  _inited = true;

  // Buttons
  for (uint8_t i=0;i<2;i++) {
    pinMode(CODELAB_BTN_PINS[i], INPUT_PULLUP);
  }

  // Motors
  for (uint8_t m=0;m<4;m++) {
    pinMode(CODELAB_MOTOR_PINS[m][0], OUTPUT);
    pinMode(CODELAB_MOTOR_PINS[m][1], OUTPUT);
    digitalWrite(CODELAB_MOTOR_PINS[m][0], LOW);
    digitalWrite(CODELAB_MOTOR_PINS[m][1], LOW);
  }

  // Buzzer
  pinMode(CODELAB_BUZZER_PIN, OUTPUT);
  digitalWrite(CODELAB_BUZZER_PIN, LOW);

  // I2C OLED
  CODELAB_Wire.begin();
  display.begin(SSD1306_SWITCHCAPVCC, CODELAB_OLED_ADDR);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0,0);
  display.println(F("CODELAB Ready"));
  display.display();

  // ADC init (using default SPI). If your ADC lib exposes different begin, adapt here.
  _adc.begin(); // Expecting the uploaded ADC128S102 lib to handle defaults (SPI + CS=9 internally or via global define)
}

void motor(int index, int speedPercent) {
  if (!_inited) begin();
  if (index < 0 || index > 3) return;
  uint8_t in1 = CODELAB_MOTOR_PINS[index][0];
  uint8_t in2 = CODELAB_MOTOR_PINS[index][1];

  int s = speedPercent;
  if (s == 0) {
    analogWrite(in1, 0);
    analogWrite(in2, 0);
    return;
  }
  uint8_t duty = pctToPWM(s);
  if (s > 0) {
    analogWrite(in1, duty);
    analogWrite(in2, 0);
  } else {
    analogWrite(in1, 0);
    analogWrite(in2, duty);
  }
}


void motor_stop(int index) {
  if (!_inited) begin();
  if (index < 0 || index > 3) return;
  uint8_t in1 = CODELAB_MOTOR_PINS[index][0];
  uint8_t in2 = CODELAB_MOTOR_PINS[index][1];
  analogWrite(in1, 0);
  analogWrite(in2, 0);
}
int sw(int index) {
  if (!_inited) begin();
  if (index < 0 || index > 1) return 0;
  // INPUT_PULLUP => pressed == LOW
  return digitalRead(CODELAB_BTN_PINS[index]) == LOW ? 1 : 0;
}

void servo(int index, int angleDeg) {
  if (!_inited) begin();
  if (index < 0 || index > 5) return;
  if (!_servoAttached[index]) {
    _servos[index].attach(CODELAB_SERVO_PINS[index]);
    _servoAttached[index] = true;
  }
  if (angleDeg < 0) angleDeg = 0;
  if (angleDeg > 180) angleDeg = 180;
  _servos[index].write(angleDeg);
}

int sen(uint8_t channel) {
  if (!_inited) begin();
  if (channel > 7) return 0;
  // readRaw returns 12-bit value 0..4095 (expected)
  return _adc.readADC(channel);
}


void stop(int index) {
  if (!_inited) begin();
  if (index < 0 || index > 3) return;
  uint8_t in1 = CODELAB_MOTOR_PINS[index][0];
  uint8_t in2 = CODELAB_MOTOR_PINS[index][1];
  analogWrite(in1, 0);
  analogWrite(in2, 0);
}
void buzz(int freqHz, int durationMs) {
  if (!_inited) begin();
  // Prefer Arduino tone() if available
  #if defined(tone)
    tone(CODELAB_BUZZER_PIN, freqHz, durationMs);
  #else
    // Simple software beep as fallback (not precise)
    unsigned long period_us = 1000000UL / (unsigned long)max(1,freqHz);
    unsigned long tEnd = millis() + durationMs;
    while ((long)(millis() - tEnd) < 0) {
      digitalWrite(CODELAB_BUZZER_PIN, HIGH);
      delayMicroseconds(period_us/2);
      digitalWrite(CODELAB_BUZZER_PIN, LOW);
      delayMicroseconds(period_us/2);
    }
  #endif
}

void beep(int durationMs) { buzz(2000, durationMs); }
void beepOK()             { buzz(2500, 120); }
void beepErr()            { buzz(400, 200); }

} // namespace CODELAB
