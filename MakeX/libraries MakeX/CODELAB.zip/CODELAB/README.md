# CODELAB Library

This folder is ready to be zipped and dropped into your Arduino `libraries/` directory.
See `docs/Manual_CODELAB.md` for full usage.
