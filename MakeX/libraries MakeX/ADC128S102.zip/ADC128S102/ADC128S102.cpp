#include "ADC128S102.h"

/**
 * Constructor.
 */
ADC128S102::ADC128S102()
{}

/**
 * Use this in the setup() method to initialize the hardware and begin mySPI if it hasn't already.
 */
void ADC128S102::begin()
{
    // initialize hardware
    pinMode(SS, OUTPUT);
    mySPI.begin();
}

/**
 * Supply the channel number to read the Analog value converted to 12-bit
 */
int16_t ADC128S102::readADC(int8_t channel){

    mySPI.beginTransaction(settings);
    // mySPI.beginTransaction(MSBFIRST,2);
    byte control = channel << 3; // DONTC DONTC ADD2 ADD1 ADD0 DONTC DONTC DONTC

    digitalWrite(SS, LOW); // Drive Slave Select LOW to select chip
    mySPI.transfer(control);
    mySPI.transfer(0x00);
    digitalWrite(SS, HIGH); // Drive Slave Select HIGH so other hardware can use mySPI

    
    digitalWrite(SS, LOW); // Drive Slave Select HIGH so other hardware can use mySPI
    buffer = mySPI.transfer(control);
    buffer = buffer << 8;
    buffer = buffer | mySPI.transfer(0x00);
    digitalWrite(SS, HIGH); // Drive Slave Select HIGH so other hardware can use mySPI
 
    
    mySPI.endTransaction();

    return buffer;
}