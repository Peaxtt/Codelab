#ifndef _ADC128S102_H_
#define _ADC128S102_H_

#include <Arduino.h>
#include <SPI.h>
#include <SWSPI.h>


class ADC128S102
{
public:
    /**
     * Constructor
     */
    ADC128S102();

    void begin();
    int16_t readADC(int8_t channel);

private:
    SPISettings settings = SPISettings(1600000, MSBFIRST, SPI_MODE0); //SPI_MODE2
    int16_t buffer;
    int SS = 9;
    MbedSPI mySPI = MbedSPI(0,7,6);
    // SWSPI mySPI = SWSPI(8,7,6);
}; 

#endif